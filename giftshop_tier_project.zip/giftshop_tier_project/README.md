Run: mvn clean install && mvn exec:java
Server on http://localhost:8085
