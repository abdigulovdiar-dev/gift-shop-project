async function fetchJSON(url, opts){ const res = await fetch(url, opts); return res.json(); }

let products = [];
let constructorSelected = new Set();
let prices = {};

async function loadProducts(){
  products = await fetchJSON('/api/products');
  const tiers = { S:[], A:[], B:[], C:[] };
  products.forEach(p=>{
    const t = (p.tier||'C').toUpperCase();
    tiers[t] = tiers[t] || [];
    tiers[t].push(p);
    prices[p.id] = p.price;
  });

  ['S','A','B','C'].forEach(t=>{
    const container = document.querySelector('#tier-'+t+' .list');
    container.innerHTML = '';
    (tiers[t]||[]).forEach(it=>{
      const row = document.createElement('div'); row.className='row';
      row.innerHTML = `<div><b>${it.name}</b><div style="font-size:12px;color:#bdbdbd">${it.description}</div></div><div><button data-id="${it.id}">Добавить</button></div>`;
      container.appendChild(row);
    });
  });

  // constructor list
  const cons = document.getElementById('constructorList');
  cons.innerHTML = '';
  products.forEach(p=>{
    const div = document.createElement('div'); div.className='c-row';
    div.innerHTML = `<input type="checkbox" data-id="${p.id}"> <div style="flex:1"><b>${p.name}</b><div style="font-size:12px;color:#bdbdbd">${p.description}</div></div> <div>${p.price} ₸</div>`;
    cons.appendChild(div);
  });

  // add handlers for tier add buttons (adds single item to cart)
  document.querySelectorAll('.list .row button').forEach(b=>b.onclick = async (e)=>{
    const id = b.dataset.id;
    await fetch('/api/add?id='+id, {method:'POST'});
    alert('Товар добавлен в корзину');
  });

  // hooks for constructor checkboxes
  document.querySelectorAll('.constructor-list input[type=checkbox]').forEach(ch=>{
    ch.onchange = ()=>{
      const id = parseInt(ch.dataset.id);
      if (ch.checked) constructorSelected.add(id); else constructorSelected.delete(id);
      updateBundleTotal();
    };
  });
  updateBundleTotal();
}

function updateBundleTotal(){
  let sum = 0;
  constructorSelected.forEach(id=> sum += (prices[id]||0));
  document.getElementById('bundleTotal').innerText = sum;
}

document.getElementById('createBundleBtn').onclick = async ()=>{
  const name = document.getElementById('bundleName').value.trim();
  if (!name) { alert('Введите название набора'); return; }
  if (constructorSelected.size===0) { alert('Выберите хотя бы один элемент'); return; }
  const items = Array.from(constructorSelected);
  const total = items.reduce((a,id)=> a + (prices[id]||0), 0);
  const body = { name, items, total };
  const res = await fetch('/api/create-custom-bundle', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)});
  const j = await res.json();
  if (j.status==='ok') {
    alert('Набор добавлен в корзину');
    constructorSelected.clear();
    document.querySelectorAll('.constructor-list input[type=checkbox]').forEach(ch=>ch.checked=false);
    updateBundleTotal();
  } else {
    alert('Ошибка: ' + (j.message||''));
  }
};

// cart modal
document.getElementById('open-cart').onclick = async () => {
    const modal = document.getElementById('cartModal');
    const content = document.getElementById('cartContent');
    const data = await fetchJSON('/api/cart');
    content.innerHTML = '';

    // Если корзина пуста
    if ((data.items || []).length === 0 && (data.bundles || []).length === 0) {
        content.innerHTML = '<p>Корзина пуста</p>';
        modal.classList.remove('hidden');
        return;
    }

    // ------------------------------
    // 1. ОДИНОЧНЫЕ ТОВАРЫ
    // ------------------------------
    (data.items || []).forEach(item => {
        const div = document.createElement('div');
        div.className = 'cart-item';

        div.innerHTML = `
            <div>${item.name}</div>
            <div>${item.price} ₸</div>
            <button class="remove-item" data-id="${item.id}">Удалить</button>
        `;

        content.appendChild(div);
    });

    // ОБРАБОТЧИК УДАЛЕНИЯ ОДИНОЧНЫХ ТОВАРОВ
    content.querySelectorAll('.remove-item').forEach(btn => {
        btn.onclick = async () => {
            const id = btn.dataset.id;
            await fetch('/api/remove?id=' + id, { method: 'POST' });
            document.getElementById('open-cart').click(); // обновить корзину
        };
    });

    // ------------------------------
    // 2. НАБОРЫ
    // ------------------------------
    (data.bundles || []).forEach(bundle => {
        const div = document.createElement('div');
        div.className = 'cart-item';

        div.innerHTML = `
            <div><b>Набор: ${bundle.name}</b></div>
            <div>${bundle.total} ₸</div>
            <button class="remove-bundle" data-id="${bundle.id}">Удалить набор</button>
        `;

        content.appendChild(div);
    });

    // ОБРАБОТЧИК УДАЛЕНИЯ НАБОРА
    content.querySelectorAll('.remove-bundle').forEach(btn => {
        btn.onclick = async () => {
            const id = btn.dataset.id;
            await fetch('/api/remove-bundle?id=' + id, { method: 'POST' });
            document.getElementById('open-cart').click();
        };
    });

    modal.classList.remove('hidden');
};


document.getElementById('closeCart').onclick = ()=>{ document.getElementById('cartModal').classList.add('hidden'); };

window.addEventListener('load', loadProducts);