package com.shop;

import static spark.Spark.*;
import com.google.gson.Gson;
import java.sql.*;
import java.io.File;
import java.util.*;

public class App {
    static Gson gson = new Gson();

    public static Connection getConn() throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:gifts.db");
    }

    public static void main(String[] args) throws Exception {
        port(8085);
        staticFiles.externalLocation(new File("frontend").getAbsolutePath());

        // Ensure tables exist
        try (Connection c = getConn()) {
            c.createStatement().execute("CREATE TABLE IF NOT EXISTS gifts (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, price INTEGER, description TEXT, tier TEXT)");
            c.createStatement().execute("CREATE TABLE IF NOT EXISTS custom_sets (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, items TEXT, total INTEGER)");
        }

        // API: products (include tier)
        get("/api/products", (req, res) -> {
            res.type("application/json; charset=UTF-8");
            List<Map<String,Object>> out = new ArrayList<>();
            try (Connection conn = getConn()) {
                PreparedStatement ps = conn.prepareStatement("SELECT id, name, price, description, tier FROM gifts");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Map<String,Object> m = new HashMap<>();
                    m.put("id", rs.getInt("id"));
                    m.put("name", rs.getString("name"));
                    m.put("price", rs.getInt("price"));
                    m.put("description", rs.getString("description"));
                    m.put("tier", rs.getString("tier"));
                    out.add(m);
                }
            }
            return gson.toJson(out);
        });

        // Create custom bundle: save to DB and add to session bundles list
        post("/api/create-custom-bundle", (req, res) -> {
            res.type("application/json; charset=UTF-8");
            Map data = gson.fromJson(req.body(), Map.class);
            String name = (String) data.getOrDefault("name", "Набор пользователя");
            List<Double> items = (List<Double>) data.get("items");
            Double totalD = (Double) data.get("total");
            int total = totalD == null ? 0 : totalD.intValue();

            // save to DB
            try (Connection conn = getConn()) {
                PreparedStatement ps = conn.prepareStatement("INSERT INTO custom_sets(name, items, total) VALUES(?,?,?)", Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, name);
                ps.setString(2, items.toString());
                ps.setInt(3, total);
                ps.executeUpdate();
                ResultSet keys = ps.getGeneratedKeys();
                int setId = -1;
                if (keys.next()) setId = keys.getInt(1);

                // add to session bundles
                List<Map<String,Object>> bundles = req.session(true).attribute("bundles");
                if (bundles == null) bundles = new ArrayList<>();
                Map<String,Object> bundle = new HashMap<>();
                bundle.put("id", setId);
                bundle.put("name", name);
                bundle.put("items", items);
                bundle.put("total", total);
                bundles.add(bundle);
                req.session().attribute("bundles", bundles);
            }
            return gson.toJson(Map.of("status","ok","message","Bundle created and added to cart"));
        });

        // API: get cart (items + bundles)
        get("/api/cart", (req, res) -> {
            res.type("application/json; charset=UTF-8");
            // items in simple cart (ids)
            List<Integer> cart = req.session(true).attribute("cart");
            if (cart == null) cart = new ArrayList<>();
            List<Map<String,Object>> items = new ArrayList<>();
            try (Connection conn = getConn()) {
                for (Integer id : cart) {
                    PreparedStatement ps = conn.prepareStatement("SELECT id, name, price FROM gifts WHERE id=?");
                    ps.setInt(1, id);
                    ResultSet rs = ps.executeQuery();
                    if (rs.next()) {
                        Map<String,Object> it = new HashMap<>();
                        it.put("id", rs.getInt("id"));
                        it.put("name", rs.getString("name"));
                        it.put("price", rs.getInt("price"));
                        items.add(it);
                    }
                }
            }

            List<Map<String,Object>> bundles = req.session().attribute("bundles");
            if (bundles == null) bundles = new ArrayList<>();

            Map<String,Object> out = new HashMap<>();
            out.put("items", items);
            out.put("bundles", bundles);
            return gson.toJson(out);
        });

        // add single item to cart
        post("/api/add", (req, res) -> {
            res.type("application/json; charset=UTF-8");
            int id = Integer.parseInt(req.queryParams("id"));
            List<Integer> cart = req.session(true).attribute("cart");
            if (cart == null) cart = new ArrayList<>();
            cart.add(id);
            req.session().attribute("cart", cart);
            return gson.toJson(Map.of("status","ok"));
        });

        // remove single item
        post("/api/remove", (req, res) -> {
            res.type("application/json; charset=UTF-8");
            int id = Integer.parseInt(req.queryParams("id"));
            List<Integer> cart = req.session(true).attribute("cart");
            if (cart == null) cart = new ArrayList<>();
            cart.removeIf(i -> i==id);
            req.session().attribute("cart", cart);
            return gson.toJson(Map.of("status","ok"));
        });

        // remove bundle from session bundles
        post("/api/remove-bundle", (req, res) -> {
            res.type("application/json; charset=UTF-8");
            int id = Integer.parseInt(req.queryParams("id"));
            List<Map<String,Object>> bundles = req.session(true).attribute("bundles");
            if (bundles == null) bundles = new ArrayList<>();
            bundles.removeIf(b -> ((Number)b.get("id")).intValue() == id);
            req.session().attribute("bundles", bundles);
            return gson.toJson(Map.of("status","ok"));
        });

        get("/", (req, res) -> { res.redirect("/index.html"); return ""; });

        System.out.println("SERVER STARTED!");
    }
}
